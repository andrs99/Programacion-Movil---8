package com.example.pokedex

import android.content.Context
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import java.lang.ClassCastException


class ListFragment : Fragment() {

    interface PokemonSelectListener{
        fun onPokemonSelected(pokemon:Pokemon)
    }

    private lateinit var pokemonSelectListener: PokemonSelectListener

    override fun onAttach(context: Context) {
        super.onAttach(context)
        pokemonSelectListener = try {
            context as PokemonSelectListener
        }catch (e: ClassCastException){
            throw ClassCastException("$context must implement PokemonSelectListener")
        }
    }

override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val view = inflater.inflate(R.layout.fragment_list, container, false)

        val recycler = view.findViewById<RecyclerView>(R.id.pokemon_recycler)
        recycler.layoutManager = LinearLayoutManager(requireActivity())

        val adapter = PokemonAdapter()
        recycler.adapter = adapter

        adapter.onItemClickListener = {
            pokemonSelectListener.onPokemonSelected(it)
        }

    val pokemonList = mutableListOf(
        Pokemon(1, "Bulbasaur", 45, 49,
            49, 45, Pokemon.PokemonType.GRASS, "https://1.bp.blogspot.com/-v53kQK3CPRk/VMw9FEHqvdI/AAAAAAAAAc0/K6z6oiwyYvg/s1600/Screenshot_2015-01-30-20-15-45.png", R.raw.bulbasaur),
        Pokemon(2, "Squirtle", 55, 65,
            53, 50, Pokemon.PokemonType.WATER, "https://www.bing.com/images/search?view=detailV2&ccid=DUqqlY%2bs&id=8E7C177659C583EF9E0BE05035C36021BE03057A&thid=OIP.DUqqlY-s1Hv54rv4hRQogQHaEK&mediaurl=https%3a%2f%2fpicon.ngfiles.com%2f759000%2fflash_759629_largest_crop.png%3ff1600891638&cdnurl=https%3a%2f%2fth.bing.com%2fth%2fid%2fR0d4aaa958facd47bf9e2bbf885142881%3frik%3degUDviFgwzVQ4A%26pid%3dImgRaw&exph=823&expw=1463&q=squirtle&simid=608054978520829519&ck=89EC33400594B11E6D161EEE0E9EFFB5&selectedIndex=20&FORM=IRPRST", R.raw.squirtle),
        Pokemon(3, "Charmeleon", 65, 89,
            115, 92, Pokemon.PokemonType.FIRE, "https://th.bing.com/th/id/OIP.b-ax0xV4s5fJw3Gzf0qfCwHaEo?pid=ImgDet&rs=1", R.raw.charmeleon),
        Pokemon(4, "Pikachu", 36, 46,
            32, 68, Pokemon.PokemonType.ELECTRIC, "https://th.bing.com/th/id/Rd9994faa14d7f2ad9f0657dd7554c937?rik=IGELwjV5euntVg&riu=http%3a%2f%2fwww.gamerfocus.co%2fwp-content%2fuploads%2f2013%2f10%2fPikacgu.png&ehk=tiLwqpTVIZIdaCwWi3emyvgV%2fQn0skm98W5%2bcOJXYgQ%3d&risl=&pid=ImgRaw", R.raw.pikachu)
    )

    adapter.submitList(pokemonList)


    return view
    }
}