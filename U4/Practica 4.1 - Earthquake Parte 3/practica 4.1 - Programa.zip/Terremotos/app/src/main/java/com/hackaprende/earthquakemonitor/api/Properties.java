package com.hackaprende.earthquakemonitor.api;

public class Properties {
    private double mag;
    private String place;
    private long time;

    public double getMag() {
        return mag;
    }

    public String getPlace() {
        return place;
    }

    public long getTime() {
        return time;
    }
}
